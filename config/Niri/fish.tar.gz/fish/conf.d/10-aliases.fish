# -----------------------------------------------------
# GENERAL
# -----------------------------------------------------
alias c='clear'
alias nf='fastfetch'
alias pf='fastfetch'
alias ff='fastfetch'
alias bum='systemctl poweroff'
alias shutdown='systemctl poweroff'
alias copy='wl-copy'

# -----------------------------------------------------
# Random
# -----------------------------------------------------
alias suso='sudo'
alias +x='chmod +x'
alias clear-links='find . -type l ! -exec test -e {} \; -delete'
alias update-grub='sudo grub-mkconfig -o /boot/grub/grub.cfg'
alias gparted='xhost +si:localuser:root && sudo gparted && xhost -si:localuser:root'

alias metrolist='~/repos/Metrolist/gradlew :app:assembleDebug && adb install -r app/build/outputs/apk/foss/debug/app-foss-debug.apk'

# -----------------------------------------------------
# Maincra
# -----------------------------------------------------

alias mc-start='docker compose -f ~/ServerMaincra/docker-compose.yml up -d'
alias mc-stop='docker compose -f ~/ServerMaincra/docker-compose.yml down'
alias mc-logs='docker logs -f mc'

alias lc-start='docker compose -f ~/ServerMaincra/docker-compose.luck.yml up -d'
alias lc-stop='docker compose -f ~/ServerMaincra/docker-compose.luck.yml down'
alias lc-logs='docker logs -f lucky'
alias lc-death='docker exec -i lucky rcon-cli scoreboard objectives add Muertes deathCount Muertes && docker exec -i lucky rcon-cli scoreboard objectives setdisplay sidebar Muertes'
alias lc-deathr='docker exec -i lucky rcon-cli scoreboard objectives remove Muertes && docker exec -i lucky rcon-cli scoreboard objectives add Muertes deathCount Muertes && docker exec -i lucky rcon-cli scoreboard objectives setdisplay sidebar Muertes'

## Comandos lucky block (World Edit)

# -----------------------------
# Borrar basura
# -----------------------------

# Seleccionar aréa, esquina (un bloque encima) y esquina 2, la torre
# // set 0

# Items del suelo
# /kill @e[type=Item]

# -----------------------------
# Cargar casa
# -----------------------------

# //schematic load casita
# //paste

# -----------------------------
# Crear base
# -----------------------------

# Seleccionar área
# //set bedrock

alias mc-afk='MEMORY=4G INIT_MEMORY=1G docker compose -f ~/ServerMaincra/docker-compose.yml up -d'
alias afk-fe='docker exec -i mc rcon-cli -- player VEGETTA777 spawn at 5540 142 -3093 && sleep 1 && docker exec -i mc rcon-cli -- gamemode spectator VEGETTA777'
alias afk-aldeanos='docker exec -i mc rcon-cli -- player ElRichMC spawn at 5607 95 -3264 && sleep 1 && docker exec -i mc rcon-cli -- gamemode spectator ElRichMC'
alias afk-all='docker exec -i mc rcon-cli -- player VEGETTA777 spawn at 5540 143 -3093 && sleep 1 && docker exec -i mc rcon-cli -- gamemode spectator VEGETTA777 && docker exec -i mc rcon-cli -- player LuzuVlogs spawn at 5569 65 -3185 && sleep 2 && docker exec -i mc rcon-cli -- gamemode spectator LuzuVlogs'
alias afk-oro='docker exec -i mc rcon-cli -- execute in minecraft:the_nether run player elrubius spawn at 639 309 -420 && sleep 2 && docker exec -i mc rcon-cli -- gamemode creative elrubius'
alias afk-stop='docker exec -i mc rcon-cli -- player VEGETTA777 kill && docker exec -i mc rcon-cli -- player ElRichMC kill && docker exec -i mc rcon-cli -- player elrubius kill'
alias afk-list='docker exec -i mc rcon-cli -- list'
alias mc-errors='docker logs mc 2>&1 | grep -E "WARN|ERROR" > erroresMC.txt'
alias mc-console='docker exec -it mc rcon-cli'
alias tailu='sudo tailscale up'
alias taild='sudo tailscale down'

# -----------------------------------------------------
# Pacman y cachy
# -----------------------------------------------------

alias niri-apps-id='niri msg -j windows | jq -r \'.[] | "\(.title) -> \(.app_id)"\''
alias niri-select-app-id="niri msg pick-window"

# -----------------------------------------------------
# Pacman y cachy
# -----------------------------------------------------

# Actualizar y ordenar los mirrors de CachyOS por velocidad
# (Usa la herramienta propia de CachyOS para ratear sus repositorios)
alias mirrors="sudo cachyos-rate-mirrors"
alias update-mirrors="sudo cachyos-rate-mirrors"

# Buscar un paquete en los repositorios usando palabras clave
# (Reemplaza el típico 'pacman -Ss')
alias pac-find="pacman -Ss"

# Buscar un paquete que YA tienes instalado en tu sistema
alias pac-find-local="pacman -Qs"

# Ver toda la información detallada de un paquete específico
alias pac-info="pacman -Si"

# Ver los archivos que contiene un paquete instalado
alias pac-files="pacman -Ql"

# Ver paquetes instalados
# (Muestra todos, para filtrar con grep tete)
alias pac-pak='pacman -Q'

# Limpiar el caché de paquetes descargados para recuperar espacio
# (Borra los paquetes antiguos guardados, dejando solo los últimos instalados)
alias pac-cache="sudo pacman -Sc"

# Eliminar paquetes "huérfanos" (dependencias que se quedaron colgadas y ya ningún programa usa)
alias pac-clean="sudo pacman -Rns (pacman -Qtdq)"

# Actualizar los mirrors generales de Arch Linux usando reflector (optimizado por velocidad/país)
alias arch-mirrors="sudo reflector --protocol https --latest 20 --sort rate --save /etc/pacman.d/mirrorlist"

# -----------------------------------------------------
# ARCHIVOS Y NAVEGACIÓN
# -----------------------------------------------------
alias cp='cp -iv'
alias mv='mv -iv'
alias rm='rm -v'
alias mkdir='mkdir -p'
alias f='finder'
alias u='yay -Rns'
alias i='yay -S'
alias ..='z ..'
alias ...='z ../..'

function nvim
    if isatty stdin
        # Si abres Neovim normal, lanza tu script de Kitty
        nv $argv
    else
        # Si detecta un pipe (ej. ls | nvim), usa el Neovim de verdad en la propia terminal
        command nvim $argv
    end
end

# Para mantener la comodidad de la letra 'n':
function n
    nvim $argv
end
# 2. Sobrescribe z para que haga cd y luego ls
function z
    __zoxide_z $argv
    ls
end

# -----------------------------------------------------
# HERRAMIENTAS MODERNAS
# -----------------------------------------------------
#alias ls='eza -a --icons=always --group-directories-first -I ".vboxclient*"'
alias ls='eza -a --icons=always --group-directories-first'
alias ll='eza -alh --icons=always --group-directories-first'
alias lt='eza -a --tree --level=1 --icons=always'
alias bat='bat --style=grid,header --paging=never'
alias cat='bat --style=grid,header --paging=never'
alias batn='bat'
alias catn='bat'
# alias grep='rg'
alias df='duf'
alias lsdisco='duf'
alias du='dust'
alias top='btop'
alias htop='btop'
alias disco='ncdu'
alias man='tldr'

alias gs="git status"
alias lg="lazygit"
alias ga="git add ."
alias gcm="git commit -m"
alias gc="git clone"
alias gC="git clone"
alias gp="git push"
alias gpl="git pull"
alias gst="git stash"
alias gsp="git stash; git pull"
alias gfo="git fetch origin"
alias gcheck="git checkout"
alias gcredential="git config credential.helper store"
